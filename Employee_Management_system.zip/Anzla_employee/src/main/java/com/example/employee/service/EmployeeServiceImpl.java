package com.example.employee.service;

import com.example.employee.model.Employee;
import com.example.employee.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository userRepository;
    //private BCryptPasswordEncoder passwordEncoder;

    @Override
    public Employee saveEmployee(Employee user) {
        //user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    @Override
    public Employee loginUser(String email, String password) {
        Employee user = userRepository.findByEmailAndPassword(email,password);

        //if (user != null && passwordEncoder.matches(password, user.getPassword()))
            return user;

        //return null;
    }

    @Override
    public List<Employee> getEmployees() {
        return userRepository.findAll();
    }
}

