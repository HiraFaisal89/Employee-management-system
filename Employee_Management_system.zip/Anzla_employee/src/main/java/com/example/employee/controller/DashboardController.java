package com.example.employee.controller;

import com.example.employee.model.Company;
import com.example.employee.model.Employee;
import com.example.employee.service.CompanyService;
import com.example.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

import static com.example.employee.controller.AuthenticationController.loginEmployee;

@Controller
public class DashboardController {

    @Autowired
    EmployeeService employeeService;
    @Autowired
    CompanyService  companyService;



    @GetMapping("dashboard")
    public String dashboardPage(Model employee) {
        if(loginEmployee!=null){
            employee.addAttribute("employee", loginEmployee);
            if(loginEmployee.getAccounttype()!=null) {
                return "anzla/dashboard";
            }
            return "redirect:employees-dashboard?notAdmin";
        }
        return "redirect:login?logout";
    }

    @GetMapping("employees-dashboard")
    public String employeesDashboardPage(Model employee) {
        if(loginEmployee!=null){
            employee.addAttribute("employee", loginEmployee);
            if(loginEmployee.getAccounttype()!=null) {
                return "redirect:dashboard";
            }
            return "anzla/employees-dashboard";
        }
        return "redirect:login?logout";
    }

    @GetMapping("employees")
    public String employeesPage(Model employee) {
        if(loginEmployee!=null){
            List<Employee> employees = employeeService.getEmployees();
            employee.addAttribute("employee", loginEmployee);
            employee.addAttribute("employees", employees);
            return "anzla/employees";
        }
        return "redirect:login?logout";
    }

    @GetMapping("company")
    public String companyPage(Model company) {
        if(loginEmployee!=null){
            Company employeeCompany = companyService.getCompany(loginEmployee.getCompany());
            company.addAttribute("company", employeeCompany);
            return "anzla/company";
        }
        return "redirect:login?logout";
    }

    @GetMapping("details")
    public String DetailsPage(Model employee) {
        if(loginEmployee!=null){
            employee.addAttribute("employee", loginEmployee);
            return "anzla/details";
        }
        return "redirect:login?logout";
    }

    @PostMapping("updateBasicInformation")
    public String updateBasicInformation(@ModelAttribute Employee employee){
        loginEmployee.setName(employee.getName());
        loginEmployee.setNationailty(employee.getNationailty());
        loginEmployee.setDateofbirth(employee.getDateofbirth());
        loginEmployee.setGender(employee.getGender());
        employeeService.saveEmployee(loginEmployee);
        return "redirect:details?profileUpdated";
    }

    @GetMapping("manage")
    public String managePage() {
        return "anzla/manage";
    }

    @GetMapping("manage-leadership")
    public String manageleadershipPage() {
        return "anzla/manage-leadership";
    }

    @GetMapping("payroll")
    public String payrollPage() {
        return "anzla/payroll";
    }

    @GetMapping("payroll-admin")
    public String payrolladminPage() {
        return "anzla/payroll-admin";
    }

    @GetMapping("profile-settings")
    public String profilesettingsPage(Model employee) {
        if(loginEmployee!=null){
            employee.addAttribute("employee", loginEmployee);
            return "anzla/profile-settings";
        }
        return "redirect:login?logout";
    }

    @GetMapping("super-admin")
    public String superadminPage() {
        return "anzla/super-admin";
    }

    @GetMapping("team-lead")
    public String teamleadPage() {
        return "anzla/team-lead";
    }

    @GetMapping("team-member")
    public String teammemberPage() {
        return "anzla/team-member";
    }

    @GetMapping("time-off")
    public String timeoffPage() {
        return "anzla/time-off";
    }

    @GetMapping("add-employee")
    public String addemployeefPage() {
        return "anzla/add-employee";
    }

    @GetMapping("custom-timeoff-approver")
    public String customtimeoffapproverPage() {
        return "anzla/custom-timeoff-approver";
    }

    @GetMapping("employment")
    public String employmentPage(Model employee) {
        if(loginEmployee!=null){
            employee.addAttribute("employee", loginEmployee);
            return "anzla/employment";
        }
        return "redirect:login?logout";

    }

}