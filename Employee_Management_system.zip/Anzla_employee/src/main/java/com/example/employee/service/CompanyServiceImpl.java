package com.example.employee.service;

import com.example.employee.model.Company;
import com.example.employee.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyServiceImpl implements CompanyService {

    @Autowired
    CompanyRepository companyRepository;

    @Override
    public Company saveCompany(Company user) {
        return companyRepository.save(user);
    }

    @Override
    public Company getCompany(Company company) {
        return companyRepository.findCompanyById(company.getId());
    }
}
