package com.example.employee.service;

import com.example.employee.model.Company;
import com.example.employee.model.Employee;

import java.util.List;

public interface CompanyService {

    Company saveCompany(Company company);    // Create & Update Operation
    Company getCompany(Company company);       // Read one row Operation
}
