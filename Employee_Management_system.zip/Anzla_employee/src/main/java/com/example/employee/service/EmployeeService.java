package com.example.employee.service;


import com.example.employee.model.Employee;

import java.util.List;

public interface EmployeeService {

    Employee saveEmployee(Employee user);
    Employee loginUser(String email, String password);

    List<Employee> getEmployees();



}
