package com.example.employee.controller;

import com.example.employee.model.Employee;
import com.example.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
//@RequestMapping("/employee")
public class AuthenticationController{

    @Autowired
    EmployeeService employeeService;

    static Employee loginEmployee;

    @GetMapping("login")
    public String loginPage(Model employee) {
        employee.addAttribute("employee",new Employee());
        return "anzla/login";
    }

    @GetMapping("register")
    public String registerPage(Model employee) {
        employee.addAttribute("employee", new Employee());
        return "anzla/register";
    }

    @PostMapping("register")
    public String registerProcess(@ModelAttribute Employee employee, Model model){
        employeeService.saveEmployee(employee);
        model.addAttribute("successMessage", "Registration successful. Please login.");
        return "redirect:login";
    }

    @PostMapping("/login")
    public String loginUser(@ModelAttribute("user") Employee user) {
     loginEmployee = employeeService.loginUser(user.getEmail(), user.getPassword());
        if (loginEmployee!=null) {
            if(loginEmployee.getPassword().equals(user.getPassword())) {
                if(loginEmployee.getAccounttype()!=null) {
                    return "redirect:dashboard";
                }
                return "redirect:employees-dashboard";
            }
        }
        return "redirect:login?incorrectCredential";
    }

    @GetMapping("logout")
    public String logout() {
        return "redirect:login?logout";
    }
}


