package com.example.employee.model;

public class Leave {



}
